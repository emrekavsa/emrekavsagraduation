"use client"
import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { useApp } from '@/context/AppContext'

export default function Login({ isOpen, onClose }) {
  const { isDark } = useApp()
  const [mode, setMode] = useState('login')
  const [form, setForm] = useState({ email: '', password: '', username: '' })
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!isOpen) {
      setForm({ email: '', password: '', username: '' })
      setMode('login')
    }
  }, [isOpen])

  if (!isOpen) return null

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  const handleAuth = async (e) => {
    if (e) e.preventDefault()
    if (loading) return

    setLoading(true)

    try {
      if (mode === 'login') {
        const { error } = await supabase.auth.signInWithPassword({
          email: form.email,
          password: form.password,
        })
        if (error) throw error
        onClose()
      } else {
        const { error } = await supabase.auth.signUp({
          email: form.email,
          password: form.password,
          options: {
            data: { username: form.username }
          }
        })
        if (error) throw error
        alert("Registration successful! Now you can log in.")
        setMode('login')
      }
    } catch (err) {
      alert(err.message || "An error occurred")
    } finally {
      setLoading(false)
    }
  }

  const inputClass = `w-full px-4 py-2.5 border rounded-xl outline-none text-sm transition-all ${
    isDark ? 'bg-zinc-800 border-zinc-700 text-white' : 'bg-gray-50 border-gray-200 text-black'
  }`

  return (
    <div className="fixed inset-0 z-[999] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className={`p-6 w-full max-w-sm border rounded-2xl ${
        isDark ? 'bg-zinc-900 border-zinc-800 text-white' : 'bg-white border-gray-200 text-black'
      }`}>

        <div className={`flex gap-1 mb-5 p-1 rounded-xl ${isDark ? 'bg-zinc-800' : 'bg-gray-100'}`}>
          <button
            type="button"
            onClick={() => setMode('login')}
            className={`flex-1 py-2 rounded-lg font-bold text-sm transition-all ${
              mode === 'login' ? 'bg-blue-600 text-white' : isDark ? 'text-zinc-400' : 'text-gray-400'
            }`}
          >
            Log in
          </button>
          <button
            type="button"
            onClick={() => setMode('register')}
            className={`flex-1 py-2 rounded-lg font-bold text-sm transition-all ${
              mode === 'register' ? 'bg-blue-600 text-white' : isDark ? 'text-zinc-400' : 'text-gray-400'
            }`}
          >
            Register
          </button>
        </div>

        <form onSubmit={handleAuth} className="flex flex-col gap-2.5">
          {mode === 'register' && (
            <input
              name="username"
              placeholder="Username"
              required
              value={form.username}
              onChange={handleChange}
              className={inputClass}
            />
          )}
          <input
            name="email"
            type="email"
            placeholder="Email"
            required
            value={form.email}
            onChange={handleChange}
            className={inputClass}
          />
          <input
            name="password"
            type="password"
            placeholder="Password"
            required
            value={form.password}
            onChange={handleChange}
            className={inputClass}
          />

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 mt-1 bg-blue-600 text-white rounded-xl font-bold text-sm disabled:opacity-50 transition-all hover:bg-blue-700"
          >
            {loading ? 'Processing...' : (mode === 'login' ? 'Continue' : 'Create account')}
          </button>
        </form>

        <button
          type="button"
          onClick={onClose}
          className="mt-4 w-full text-center text-xs text-gray-400 hover:text-red-500 transition-colors"
        >
          Dismiss
        </button>

      </div>
    </div>
  )
}